<?php 
$hostname="localhost";
$username="root";
$password="";
$dbname="hopengo";

$conn=mysqli_connect($hostname,$username,$password,$dbname);
//cnnection variable
 ?>
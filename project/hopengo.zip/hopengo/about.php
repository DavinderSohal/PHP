<!DOCTYPE html>
<html lang="en">
<head>
<title>Hope Animal Welfare Society</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<meta name="keywords" content="Harvest Life Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="icon" type="image/png" href="images/himage2.png"/>
<link href="//fonts.googleapis.com/css?family=Playball&amp;subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script> 
</head>
<body>
	<div class="banner about-banner">
		<div class="header">
			<div class="container">
				<div class="header-left">
					<div class="w3layouts-logo">
						<h1>
							<a href="index.php">Hope <span><sup>Life</sup></span></a>
						</h1>
					</div>
				</div>
				<div class="header-right">
					<div class="agileinfo-social-grids">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-rss"></i></a></li>
							<li><a href="#"><i class="fa fa-vk"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="header-bottom">
			<div class="container">
				<div class="top-nav">
						<nav class="navbar navbar-default">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
								</div>
							<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
								<ul class="nav navbar-nav">
									<li><a class="list-border" href="index.php">Home</a></li>
									<li class="active"><a href="#" class="dropdown-toggle hvr-bounce-to-bottom" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About Us<span class="caret"></span></a>
										<ul class="dropdown-menu">
										<li><a class="hvr-bounce-to-bottom" href="about.php">About Hope</a></li>
											<li><a class="hvr-bounce-to-bottom" href="misson.php">Our mission</a></li>
											<li><a class="hvr-bounce-to-bottom" href="helpline.php">Our Helpline</a></li>     
											 <li><a class="hvr-bounce-to-bottom" href="testimonials.php">Testimonials</a></li>
										</ul>
									</li>									<li><a href="Donars.php">Donars</a></li>	
								    <li class=""><a href="#" class="dropdown-toggle hvr-bounce-to-bottom" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Gallery<span class="caret"></span></a>
										<ul class="dropdown-menu">
											<li><a class="hvr-bounce-to-bottom" href="gallery.php">Our Gallery</a></li>
											<li><a class="hvr-bounce-to-bottom" href="animals.php">Our Family</a></li>     
										</ul>
									</li>	
									<li><a href="news.php">News/Events</a></li>
									<li><a class="list-border1" href="contact.php">Contact</a></li>
								</ul>	
								<div class="clearfix"> </div>
							</div>	
						</nav>		
				</div>
			</div>
		</div>
	</div>
	<!-- //banner -->
	<!-- a-about -->
	<div class="a-grid">
		<div class="container">
			<div class="w3l-about-heading">
				<h2>About <span>Hope</span></h2>
			</div>
			<div class="agileits-a-about-grids">
				<div class="col-md-5 agileits-a-about-left">
					<img src="images/211.jpg" alt="" />
				</div>
				<div class="col-md-7 agileits-a-about-right">
					<h3>A few words about us</h3>
					<h4>H.O.P.E is a private, non-profit, tax-exempt organization committed to caring for unwanted animals and providing them with preventative medical treatment, food and shelter until we can find them a new home. Founded in 1961, HOPE is incorporated by the State of Michigan and is supported by Gogebic County, MI and Iron County, WI appropriations, adoption fees, donations and volunteers. HOPE believes that all life should be revered and that all living creatures should be treated with kindness and respect. </h4>
						<p><span>H.O.P.E. Animal Shelter is seeking temporary foster homes for a couple of dogs that need a break from the shelter.Please contact HOPE for more information if interested in helping out as a foster parent.H.O.P.E. is a non-profit 501 (c)(3) organization dedicated to helping and promoting the adoption of lost, stray and abandoned cats and dogs into great forever homes. .</span>
					</p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //a-about -->
	<!-- different -->
	<div class="jarallax different">
		<div class="container">
			<div class="w3-different-heading">
				<h3>Why we are <span>different</span></h3>
				<p>We are not different in any important way!!!Care, support and ethical treatment of animals. They should can be eaten but not tortured.</p>
			</div>
			<div class="w3agile-different-info">
				<p>Hope fights to stop animals from being used in any industry including food, clothing, accessories and experimentation. We justify that animals should be free to roam in the wild and that their ultimate goal is to liberate all animals, even domesticated ones. The organization was founded in 1961 and is headquartered in Ludhiana. HOPE has fought and won fights against many companies that abuse and misuse animals and also has multiple sponsors all over the world. Our organization works nationally to rescue animals from abuse, pass humane laws and share resources with many shelters across the country. .</p>
				<div class="w3agile-button">
					<a href="Donars.html">Please Help Us</a>
				</div>
			</div>
		</div>
	</div>
	<!-- //different -->
	<!-- team -->
	<div class="team">
		<div class="container">
			<div class="agileinfo-team-heading">
				<h3>Our <span>Team</span></h3>
			</div>
			<div class="team-grids">
				<div class="col-md-3 col-xs-6 agileinfo-team-grid">
					<img src="images/jagdeepkhera.jpg" alt="" />
					<div class="captn">
						<h4>Dr.Jagdeep Khera</h4>
						<p>President</p>
						<div class="w3l-social">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-rss"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-xs-6 agileinfo-team-grid">
					<img src="images/poonammam.jpg" alt="" />
					<div class="captn">
						<h4>Mrs Poonam</h4>
						<p>Secretary</p>
						<div class="w3l-social">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-rss"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-xs-6 agileinfo-team-grid">
					<img src="images/Leslee-Udwin-Re-L_483x643.jpg" alt="" />
					<div class="captn">
						<h4>Mrs Williams</h4>
						<p>Executive Member</p>
						<div class="w3l-social">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-rss"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-xs-6 agileinfo-team-grid">
					<img src="images/Drrajesh.jpg" alt="" />
					<div class="captn">
						<h4>Dr Rajan Kansal</h4>
						<p>Executive Member</p>
						<div class="w3l-social">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-rss"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //team -->
<?php 
include'subscribe.php' ?>
   <!-- //newsletter -->
<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="w3agile_footer_grids">
				<div class="col-md-3 agileinfo_footer_grid">
					<div class="agileits_w3layouts_footer_logo">
						<h2><a href="index.php"><span>H</span>ope<i></i></a></h2>
					</div>
				</div>
				<div class="col-md-4 agileinfo_footer_grid">
					<h3>Contact Info</h3>
					<h4>Call Us <span>+91-161-2460342</span></h4>
					<p>175-A Sarabha Nagar Ludhiana,141003.<span>Punjab(INDIA).</span></p>
					<ul class="agileinfo-social-grids12">
						<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-rss"></i></a></li>
						<li><a href="#"><i class="fa fa-vk"></i></a></li>
						</ul>
						
				</div>
				<div class="col-md-2 agileinfo_footer_grid agileinfo_footer_grid1">
					<h3>Navigation</h3>
					<ul class="w3layouts_footer_nav">
						<li><a href="index.php"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Home</a></li>
						<li><a href="About.php"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>About us</a></li>
						<li><a href="donars.php"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Donars</a></li>
						<li><a href="gallery.php"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Gallery</a></li>
						<li><a href="http://www.Hopewelfaresociety.blogspot.com"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Blog</a></li>
                        <li><a href="contact.php"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Contact Us</a></li>

					</ul>
				</div>
				<div class="col-md-3 agileinfo_footer_grid">
					<h3>Blog Posts</h3>
					<div class="agileinfo_footer_grid_left">
						<a href="#" data-toggle="modal" data-target="#myModal"><img src="images/g101.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="agileinfo_footer_grid_left">
						<a href="#" data-toggle="modal" data-target="#myModal"><img src="images/g81.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="agileinfo_footer_grid_left">
						<a href="#" data-toggle="modal" data-target="#myModal"><img src="images/g111.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="agileinfo_footer_grid_left">
						<a href="#" data-toggle="modal" data-target="#myModal"><img src="images/100.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="w3_agileits_footer_copy">
			<div class="container">
				<p>© 2018 Animals Ngo. All rights reserved | Design by <a href="#">Davinder & Rajinder.</a></p>
			</div>
		</div>
	</div>
		
<!-- //footer -->
	<!-- //copyright -->
	<script src="js/SmoothScroll.min.js"></script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<!-- //here ends scrolling icon -->
	<!-- parallax -->
	<script src="js/jarallax.js"></script>
	<script type="text/javascript">
        /* init Jarallax */
        $('.jarallax').jarallax({
            speed: 0.5,
            imgWidth: 1366,
            imgHeight: 768
        })
    </script>
	<!-- //parallax -->
</body>	
</html>
<?php 
$hostname="localhost";
$username="hopengo";
$password="hopengo";
$dbname="hopengo";

$conn=mysqli_connect($hostname,$username,$password,$dbname);
//cnnection variable
 ?>
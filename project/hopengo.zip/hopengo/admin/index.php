<?php
include'include/header.php';
include'include/sidebar1.php';
include'include/config.php';
?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        Welcome admin
<a href="logout.php">Logout</a>
        <!--/.col (left) -->
        <!-- right column -->

        <div class="col-md-2">
        </div>


        <div class="col-md-8">
          <!-- Horizontal Form -->
                    <!-- /.box -->
          <!-- general form elements disabled -->
          
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->




<?php

include 'include/footer.php';

?>